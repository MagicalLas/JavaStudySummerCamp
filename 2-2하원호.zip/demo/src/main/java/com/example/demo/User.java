package com.example.demo;

public class User {
    String name;
    String pass;
}
